def main():
    print('Welcome to HALchemy')


if __name__ == '__main__':
    main()
